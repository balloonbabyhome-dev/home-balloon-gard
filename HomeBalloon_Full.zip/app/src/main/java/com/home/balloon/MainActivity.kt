
package com.home.balloon
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import org.json.JSONArray
import org.json.JSONObject

data class بالونة(var الاسم: String, var العدد: Int, var السعر: Int, var الخصم: Int)

class MainActivity : AppCompatActivity() {
    var قائمة_البالونات = mutableListOf<بالونة>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var اسم_البالونة = findViewById<EditText>(R.id.اسم_البالونة)
        var عدد_البالونة = findViewById<EditText>(R.id.عدد_البالونة)
        var سعر_البالونة = findViewById<EditText>(R.id.سعر_البالونة)
        var خصم_البالونة = findViewById<EditText>(R.id.خصم_البالونة)
        var زرار_اضافة = findViewById<Button>(R.id.زرار_اضافة)
        var قائمة = findViewById<RecyclerView>(R.id.قائمة_البالونات)
        var اعلان = findViewById<AdView>(R.id.اعلان)
        تحميل_البيانات()
        var ادابتر = ادابتر_البالونات(قائمة_البالونات) { pos ->
            قائمة_البالونات.removeAt(pos)
            حفظ_البيانات()
            قائمة.adapter?.notifyDataSetChanged()
        }
        قائمة.layoutManager = LinearLayoutManager(this)
        قائمة.adapter = ادابتر
        MobileAds.initialize(this) {}
        اعلان.loadAd(AdRequest.Builder().build())
        زرار_اضافة.setOnClickListener {
            var الاسم = اسم_البالونة.text.toString()
            if (الاسم.isEmpty()) { اسم_البالونة.error = "اكتبي اسم"; return@setOnClickListener }
            var العدد = عدد_البالونة.text.toString().toIntOrNull() ?: 0
            var السعر = سعر_البالونة.text.toString().toIntOrNull() ?: 0
            var الخصم = خصم_البالونة.text.toString().toIntOrNull() ?: 0
            if (العدد < 10) { قائمة.setBackgroundColor(Color.parseColor("#FFCDD2")) } else { قائمة.setBackgroundColor(Color.parseColor("#FFF0F5")) }
            قائمة_البالونات.add(بالونة(الاسم, العدد, السعر, الخصم))
            حفظ_البيانات()
            ادابتر.notifyDataSetChanged()
            اسم_البالونة.text.clear(); عدد_البالونة.text.clear(); سعر_البالونة.text.clear(); خصم_البالونة.text.clear()
        }
    }
    fun حفظ_البيانات() {
        var prefs = getSharedPreferences("مخزن_البالونات", Context.MODE_PRIVATE)
        var مصفوفة = JSONArray()
        for (ب in قائمة_البالونات) {
            var كائن = JSONObject()
            كائن.put("اسم", ب.الاسم); كائن.put("عدد", ب.العدد); كائن.put("سعر", ب.السعر); كائن.put("خصم", ب.الخصم)
            مصفوفة.put(كائن)
        }
        prefs.edit().putString("بيانات", مصفوفة.toString()).apply()
    }
    fun تحميل_البيانات() {
        var prefs = getSharedPreferences("مخزن_البالونات", Context.MODE_PRIVATE)
        var نص = prefs.getString("بيانات", null) ?: return
        try {
            var مصفوفة = JSONArray(نص)
            for (i in 0 until مصفوفة.length()) {
                var كائن = مصفوفة.getJSONObject(i)
                قائمة_البالونات.add(بالونة(كائن.getString("اسم"), كائن.getInt("عدد"), كائن.getInt("سعر"), كائن.getInt("خصم")))
            }
        } catch (e: Exception) {}
    }
}

class ادابتر_البالونات(var القائمة: MutableList<بالونة>, var عند_الحذف: (Int) -> Unit) : RecyclerView.Adapter<ادابتر_البالونات.ViewHolder>() {
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var نص: TextView = view.findViewById(R.id.نص_المنتج)
        var حذف: Button = view.findViewById(R.id.زرار_حذف)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var v = LayoutInflater.from(parent.context).inflate(R.layout.item_balloon, parent, false)
        return ViewHolder(v)
    }
    override fun getItemCount(): Int = القائمة.size
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var ب = القائمة[position]
        var سعر_بعد = ب.السعر - (ب.السعر * ب.الخصم / 100)
        var نص = "🎈 ${ب.الاسم} - العدد: ${ب.العدد} - السعر: ${ب.السعر} جنيه"
        if (ب.الخصم > 0) { نص += " - خصم ${ب.الخصم}% = ${سعر_بعد} جنيه" }
        if (ب.العدد < 10) { نص += " ⚠️ العدد قليل!" }
        holder.نص.text = نص
        holder.حذف.setOnClickListener { عند_الحذف(position) }
    }
}
